﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.Core.Domain.IRepositories;
using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.IService;
using Gzy.Core.Service.Models.SysManager;
using Microsoft.Extensions.Logging;

namespace Gzy.Core.DLL.SYS
{
    public class SysManagerService : ISysManagerService
    {
        private readonly ISubSystemRepository subSysDb;
        private readonly ILogger log;
        public SysManagerService(ISubSystemRepository subSysContext,ILogger<UserService> log)
        {         
            this.subSysDb = subSysContext;           
            this.log = log;
        }
        public ResponseResultDto<SubSystemModel> DeleteSubSystem(Guid Id)
        {
            throw new NotImplementedException();
        }

        public ResponseResultDto<SubSystemModel> InsertSubSystem(SubSystemModel subSystemModel)
        {
            throw new NotImplementedException();
        }

        public ResponseResultDto<SubSystemModel> UpdateSubSystem(SubSystemModel subSystemModel)
        {
            throw new NotImplementedException();
        }
    }
}
