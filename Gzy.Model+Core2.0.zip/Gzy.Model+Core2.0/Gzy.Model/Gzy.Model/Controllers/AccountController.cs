﻿using Gzy.Core.Service.ISYS;
using Gzy.Model.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Gzy.Model.Controllers.IService
{
    public class AccountController : Controller
    {
        public IUserService _service;
        public AccountController(IUserService service)
        {
            this._service = service;
        }
        [AllowAnonymous]//允许匿名访问
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]//防止CSRF（跨网站请求伪造）。
        public async Task<IActionResult> Login(string loginname, string password)
        {
            var serviceResponse = _service.Login(loginname, password);
            if (!serviceResponse.IsSuccess)
            {
                return Content("<script>alert('" + serviceResponse.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }

            //https://www.cnblogs.com/oorz/p/8617530.html cookie授权登录参考
            var claimsIdentity = new ClaimsIdentity(
                new List<Claim>
                {
                    new Claim("loginname", serviceResponse.Result.FirstOrDefault().LoginName),
                    new Claim("password", serviceResponse.Result.FirstOrDefault().Password),
                    //new Claim(ClaimTypes.Role, "Administrator"),
                }, CookieAuthenticationDefaults.AuthenticationScheme);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity), new AuthenticationProperties
                {
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(1),// 有效时间
                    //ExpiresUtc = DateTimeOffset.Now.Add(TimeSpan.FromDays(7)), // 有效时间
                    IsPersistent = true,
                    AllowRefresh = false
                });

            return RedirectToAction("Index", "Home");//登陆成功跳转主页
        }

        [UserAuthorize]
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return LocalRedirect("/Account/Login");
        }
    }
}