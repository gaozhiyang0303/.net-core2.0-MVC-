﻿using System;
using System.Collections.Generic;
using Gzy.Core.DLL.Model;
using Gzy.Core.Service.Models.SysManager;
using Gzy.CorePublic;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Gzy.Model.Controllers
{

    public class SysManagerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        #region 获取数据表

        public IActionResult GetDataList(string condition, string keyword, Pagination pagination)
        {
            var da=new List<SubSystemModel>();
            da.Add(new SubSystemModel()
            {
                Id = Guid.NewGuid(),
                Seq = 10,
                Name = "1000",
                Icon = "200"
            });
            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(da)));
        }
        #endregion
    }
}