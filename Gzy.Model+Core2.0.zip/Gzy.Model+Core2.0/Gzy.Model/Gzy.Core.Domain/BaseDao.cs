﻿using Gzy.EF.Domain;
using Gzy.EF.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Gzy.Core.Domain
{
    public class BaseDao:IBaseDao
    {
        public DbContext Db;

       

        public BaseDao(DbContext context)
        {
            this.Db = context;
        }
        public DbContext DbContext => Db;
        #region 增删查改
        //查询
        public T Get<T>(Guid Id) where T : BaseEntity
        {
            return DbContext.Find<T>();
        }
        public List<T> GetObjects<T>() where T : BaseEntity
        {
            var ss = DbContext.Set<T>();
            return ss.ToList();
        }
        //保存
        public bool Save<T>(T o) where T : BaseEntity
        {
            try
            {
                o.OptDate = DateTime.Now;
                o.Version = 1;
                DbContext.Add(o);
                DbContext.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                DbContext.Dispose();
                throw;
            }
        }

       

        //保存
        public bool Update<T>(T o) where T : BaseEntity
        {
            try
            {
                o.OptDate = DateTime.Now;
                o.Version = o.Version + 1;
                DbContext.Attach(o);
                DbContext.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                DbContext.Dispose();
                throw;
            }
        }
        #endregion
        


    }
}
