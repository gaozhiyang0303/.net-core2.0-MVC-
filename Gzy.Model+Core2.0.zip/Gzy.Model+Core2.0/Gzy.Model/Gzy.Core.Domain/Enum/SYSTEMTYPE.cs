﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.Core.Domain.Enum
{
    public enum SYSTEMTYPE
    {
        [Display(Name = "网页")]
        Web,

        [Display(Name = "App")]
        App
    }
}
