﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Gzy.Core.Domain.Enum
{
    /// <summary>
    /// 用户类型
    /// </summary>
    public enum UserType
    {
        [Display(Name = "系统管理员")]
        Administrator,
     
        [Display(Name = "其他部门")]
        OtherAgency
    }
}
