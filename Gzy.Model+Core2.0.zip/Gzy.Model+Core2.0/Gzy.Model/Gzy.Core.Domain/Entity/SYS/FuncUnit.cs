﻿using System;
using System.ComponentModel.DataAnnotations;
using Gzy.Core.Domain.Enum;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    /// <summary>
    /// 功能单元
    /// </summary>
    public class FuncUnit : BaseEntity
    {
        /// <summary>
        /// 功能名称
        /// </summary>
        [Display(Name = "功能名称", Order = 101)]
        public virtual string Name { get; set; }

        /// <summary>
        /// 页面路径
        /// </summary>
        [Display(Name = "页面路径", Order = 102)]
        public virtual string FuncMainView { get; set; }

        [Display(Name = "所属组件", Order = 103)]
        public virtual string BelongModule { get; set; }

        /// <summary>
        /// 显示顺序
        /// </summary>
        [Display(Name = "序号", Order = 100)]
        public virtual int Seq { get; set; }

        [Display(Name = "系统类型", Order = 104)]
        public virtual SYSTEMTYPE SystemType { get; set; }

        [Display(AutoGenerateField = false)]
        public virtual Guid SubSystemID { get; set; }
    }
}
