﻿using System;
using System.ComponentModel.DataAnnotations;
using Gzy.Core.Domain.Enum;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    /// <summary>
    /// 用户
    /// </summary>
    public  class User : BaseEntity
    {
        /// <summary>
        /// 系统名称
        /// </summary>
       

        [Display(Name = "姓名", Description = "用户的名称。")]
        public virtual string UserName { get; set; }

        [Display(Name = "用户名", Description = "系统登录时将使用。")]
        public virtual string LoginName { get; set; }

        /// <summary>
        /// 口令
        /// </summary>
        [DataType(DataType.Password)]
        public virtual string Password { get; set; }

        /// <summary>
        /// 创建日期
        /// </summary>
        public virtual DateTime? StartDate { get; set; }

        /// <summary>
        /// 删除日期
        /// </summary>
        public virtual DateTime? EndDate { get; set; }
        /// <summary>
        /// 电子邮箱
        /// </summary>
        public virtual string Email { get; set; }

        public virtual Guid BelongID { get; set; }

        public virtual UserType UserType { get; set; }

        /// <summary>
        /// 角色
        /// </summary>
        public virtual string UserRoles { get; set; }

        public virtual string DefaultView { get; set; }

        ///// <summary>
        ///// 用户编码 - 微信
        ///// </summary>
        //public virtual string WxOpenId { get; set; }

    }
}
