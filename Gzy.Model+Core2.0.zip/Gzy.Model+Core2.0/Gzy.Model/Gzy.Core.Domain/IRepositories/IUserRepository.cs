﻿using Gzy.EF.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using Gzy.Core.Domain.Entity.SYS;

namespace Gzy.Core.Domain.IRepositories
{
    public interface IUserRepository:IBaseRepository<User, Guid>
    {
    }
}
