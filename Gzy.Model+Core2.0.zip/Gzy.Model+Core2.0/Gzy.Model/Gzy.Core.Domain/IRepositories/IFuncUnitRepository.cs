﻿using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Repository;
using System;

namespace Gzy.Core.Domain.IRepositories
{
    public interface IFuncUnitRepository: IBaseRepository<FuncUnit, Guid>
    {
    }
}
