﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Domain.MappingFluently.SYS
{
    public class LoginLogMapping : BaseEntityMapping<LoginLog>
   {
       public new void Configure(EntityTypeBuilder<LoginLog> builder)
       {
           builder.Property(t => t.User).HasColumnName("User_ID").IsRequired();
           builder.Property(t => t.LoginTime).HasColumnName("LoginTime").IsRequired();
           builder.Property(t => t.LastOperatorTime).HasColumnName("LastOperatorTime").IsRequired();
           builder.Property(t => t.LogoutTime).HasColumnName("LogoutTime").IsRequired();
           builder.Property(t => t.LoginTerm).HasColumnName("LoginTerm").IsRequired().HasMaxLength(30);
           builder.Property(t => t.SystemType).HasColumnName("SystemType").IsRequired();
        }
    }
}
