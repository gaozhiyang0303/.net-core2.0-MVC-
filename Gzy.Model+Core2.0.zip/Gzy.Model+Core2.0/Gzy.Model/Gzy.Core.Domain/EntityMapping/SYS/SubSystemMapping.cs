﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Domain.MappingFluently.SYS
{
    public class SubSystemMapping : BaseEntityMapping<SubSystem>
    {
        public new void Configure(EntityTypeBuilder<SubSystem> builder)
        {
            builder.Property(t => t.Seq).HasColumnName("Seq").IsRequired();
            builder.Property(t => t.Name).HasColumnName("Name").IsRequired().HasMaxLength(30);
            builder.Property(t => t.Icon).HasColumnName("Icon").IsRequired().HasMaxLength(30);
          
        }
    }
}
