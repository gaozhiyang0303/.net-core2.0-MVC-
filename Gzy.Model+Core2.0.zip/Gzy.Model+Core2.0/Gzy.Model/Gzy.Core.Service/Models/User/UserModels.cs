﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models
{
    public class UserModels
    {
        public Guid Id { get; set; }
        public  string UserName { get; set; }
        public  string LoginName { get; set; }
        /// <summary>
        /// 口令
        /// </summary>
        public  string Password { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public  DateTime? StartDate { get; set; }
        /// <summary>
        /// 删除日期
        /// </summary>
        public  DateTime? EndDate { get; set; }
        /// <summary>
        /// 电子邮箱
        /// </summary>
        public  string Email { get; set; }
        public  Guid BelongID { get; set; }
        public  string  UserTypeName { get; set; }
        /// <summary>
        /// 角色
        /// </summary>
        public  string UserRoles { get; set; }

        public  string DefaultView { get; set; }
    }
}
