﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models
{
    public class SubSystemFuncUnitModels
    {
        public Guid Id { get; set; }
        public string SubSystemName { get; set; }
        public List<FuncUnitModels> FuncUnit { get; set; }
    }

    public class FuncUnitModels
    {
        public Guid Id { get; set; }
        public string FuncUnitName { get; set; }
    }
}
