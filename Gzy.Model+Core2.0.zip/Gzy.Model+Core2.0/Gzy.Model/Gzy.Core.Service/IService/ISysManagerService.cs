﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.Models.SysManager;

namespace Gzy.Core.Service.IService
{
    public interface ISysManagerService
    {
        ResponseResultDto<SubSystemModel> InsertSubSystem(SubSystemModel subSystemModel);
        ResponseResultDto<SubSystemModel> UpdateSubSystem(SubSystemModel subSystemModel);

        ResponseResultDto<SubSystemModel> DeleteSubSystem(Guid Id);
    }
}
