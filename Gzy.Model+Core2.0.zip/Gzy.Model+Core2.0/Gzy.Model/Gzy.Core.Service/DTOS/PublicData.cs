﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.DTOS
{
    /// <summary>
    /// 返回结果统一反参
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    public class ResponseResultDto<TResult>
    {
        public bool IsSuccess { get; set; }

        public List<TResult> Result { get; set; }

        public string ErrorMessage { get; set; }
    }
    /// <summary>
    /// 跳页结果统一反参
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    public class PagedResultDto<TResult>
    {
        public List<TResult> Results { get; set; }

        public int Page { get; set; }

        public int PageSize { get; set; }

        public int Total { get; set; }
    }
}
