﻿using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.IRepositories;
using Gzy.EF.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Model.Repositories
{
    public class FuncUnitRepository: BaseRepository<FuncUnit, Guid>, IFuncUnitRepository
    {
        public FuncUnitRepository(DbContext context) : base(context) { }
    }
}
