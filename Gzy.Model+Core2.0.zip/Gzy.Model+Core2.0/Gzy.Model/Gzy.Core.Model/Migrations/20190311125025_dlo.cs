﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Gzy.Core.Model.Migrations
{
    public partial class dlo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_User_LoginLog_ID",
                table: "User");

            migrationBuilder.DropUniqueConstraint(
                name: "AK_User_ID_Name",
                table: "User");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "User");

            migrationBuilder.AddColumn<Guid>(
                name: "UserID",
                table: "LoginLog",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_LoginLog_UserID",
                table: "LoginLog",
                column: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_LoginLog_User_UserID",
                table: "LoginLog",
                column: "UserID",
                principalTable: "User",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LoginLog_User_UserID",
                table: "LoginLog");

            migrationBuilder.DropIndex(
                name: "IX_LoginLog_UserID",
                table: "LoginLog");

            migrationBuilder.DropColumn(
                name: "UserID",
                table: "LoginLog");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "User",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddUniqueConstraint(
                name: "AK_User_ID_Name",
                table: "User",
                columns: new[] { "ID", "Name" });

            migrationBuilder.AddForeignKey(
                name: "FK_User_LoginLog_ID",
                table: "User",
                column: "ID",
                principalTable: "LoginLog",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
