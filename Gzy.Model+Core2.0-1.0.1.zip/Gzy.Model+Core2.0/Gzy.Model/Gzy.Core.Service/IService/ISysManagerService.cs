﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.Core.DLL.Model;
using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.Models;
using Gzy.Core.Service.Models.SysManager;
using Gzy.Core.Service.Models.User;
using FuncUnitModels = Gzy.Core.Service.Models.SysManager.FuncUnitModels;

namespace Gzy.Core.Service.IService
{
    public interface ISysManagerService
    {
        ResponseResultDto<SubSystemModel> SaveOrUpdateSubSystem(SubSystemModel subSystemModel);

        ResponseResultDto<SubSystemModel> DeleteSubSystem(List<string> ids);
        ResponseResultDto<SubSystemModel> QuerySubSystem(string name, Pagination pagination);

        #region FuncUnit

        ResponseResultDto<FuncUnitModels> QueryFuncUnitModels(string name,Guid subId, Pagination pagination);

        ResponseResultDto<FuncUnitModels> SaveOrUpdateFuncUnitModels(FuncUnitModels funcUnitModel);
        ResponseResultDto<SubSystemModel> DeleteFuncUniSubSystem(List<string> ids);
        #endregion

        #region User

        ResponseResultDto<UserModels> QueryUserModels(string username, string rolename, Pagination pagination);
        bool SaveOrUpdateUsers(UserModels userModels);
        bool DeleteUser(List<string> ids);
        #endregion
        #region UserRole
        ResponseResultDto<UserRoleModels> QueryUserRoleModels();
        bool SaveOrUpdateRole(UserRoleModels userRoleModels);
        List<RoleAuthorizeModels> GetRoleAuthorizeModels(Guid roleId, Pagination pagination);
        bool SaveRoleAuthorize(Guid roleid, List<string> funtId);

        #endregion



    }
}
