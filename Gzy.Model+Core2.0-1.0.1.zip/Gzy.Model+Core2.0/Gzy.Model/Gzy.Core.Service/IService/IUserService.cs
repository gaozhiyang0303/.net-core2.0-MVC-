﻿using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.Models;

namespace Gzy.Core.Service.ISYS
{
    public interface IUserService
    {
        ResponseResultDto<UserModels> Login(string loginname, string password);

        ResponseResultDto<SubSystemFuncUnitModels> GetSystemFuncUnitModels();
    }
}
