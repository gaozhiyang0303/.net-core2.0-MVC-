﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models.User
{
    public class UserRoleModels
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
