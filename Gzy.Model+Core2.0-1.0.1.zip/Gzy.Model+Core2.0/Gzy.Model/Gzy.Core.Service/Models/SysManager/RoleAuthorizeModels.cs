﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models.SysManager
{
    public class RoleAuthorizeModels
    {
        public Guid Id { get; set; }
        public Guid RoleId { get; set; }

        public string FuncUnitName { get; set; }
        public bool IsChecked { get; set; }
    }
}
