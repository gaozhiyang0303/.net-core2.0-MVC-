﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models.SysManager
{
    public class SubSystemModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }//系统模块名称
        public int Seq { get; set; }//排序
        public string Icon { get; set; }//图标

    }
}
