﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.Models.SysManager
{
    public class FuncUnitModels
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string FuncMainView { get; set; }
        public int Seq { get; set; }
        public Guid SubSystemID { get; set; }
        public string SubStstemName { get; set; }
        public string BelongModule { get; set; }
        
    }
}
