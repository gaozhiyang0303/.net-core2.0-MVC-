﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Service.DTOS
{
    /// <summary>
    /// 返回结果统一反参
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    public class ResponseResultDto<TResult>
    {
        public bool IsSuccess { get; set; }

        public List<TResult> Result { get; set; }

        public string ErrorMessage { get; set; }
    }
    /// <summary>
    /// 跳页结果统一反参
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    public class PagedResultDto<TResult>
    {
        public List<TResult> Results { get; set; }

        public int Page { get; set; }

        public int PageSize { get; set; }

        public int Total { get; set; }
    }

    /// <summary>
    /// Ajax请求结果
    /// </summary>
    public class AjaxResult
    {
        /// <summary>
        /// 是否成功
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// 错误代码：
        /// 1：未登录
        /// 其它待定义
        /// </summary>
        public int ErrorCode { get; set; }

        /// <summary>
        /// 返回消息
        /// </summary>
        public string Msg { get; set; }

        /// <summary>
        /// 返回数据
        /// </summary>
        public object Data { get; set; }
    }

    
    
}
