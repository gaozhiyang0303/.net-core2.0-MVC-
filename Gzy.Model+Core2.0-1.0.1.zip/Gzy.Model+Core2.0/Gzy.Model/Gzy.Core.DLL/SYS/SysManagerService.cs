﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Coldairarrow.Util;
using Gzy.Core.DLL.Model;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.Enum;
using Gzy.Core.Domain.IRepositories;
using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.IService;
using Gzy.Core.Service.Models;
using Gzy.Core.Service.Models.SysManager;
using Gzy.Core.Service.Models.User;
using Gzy.CorePublic;
using Microsoft.Extensions.Logging;

namespace Gzy.Core.DLL.SYS
{
    public class SysManagerService : ISysManagerService
    {
        private readonly ISubSystemRepository subSysDb;
        private readonly IFuncUnitRepository funDb;
        private readonly IRoleRepository roleDb;
        private readonly IUserRepository userDb;
        private readonly IRoleAuthorizeRepository roleAuthorizeDb;
        private readonly ILogger log;
        public SysManagerService(IRoleAuthorizeRepository roleAuthorizeDbContext, IUserRepository userContext,IRoleRepository roleContext,ISubSystemRepository subSysContext, IFuncUnitRepository funDbContext, ILogger<UserService> log)
        {
            this.subSysDb = subSysContext;
            this.funDb = funDbContext;
            this.roleDb = roleContext;
            this.userDb = userContext;
            this.roleAuthorizeDb = roleAuthorizeDbContext;
            this.log = log;
        }
        #region SubSystem
        public ResponseResultDto<SubSystemModel> QuerySubSystem(string name, Pagination pagination)
        {
            ResponseResultDto<SubSystemModel> res = new ResponseResultDto<SubSystemModel>();
            try
            {
                var datas = subSysDb.Query().Where(p => !p.DeFlag);
                if (!string.IsNullOrEmpty(name))
                {
                    datas = datas.Where(p => p.Name.Contains(name));
                }

                var datalist = datas.Select(p => new SubSystemModel()
                {
                    Id = p.ID,
                    Name = p.Name,
                    Seq = p.Seq,
                    Icon = p.Icon
                });
                if (pagination != null)
                {
                    datalist = datalist.GetPagination(pagination);
                }
                res.IsSuccess = true;
                res.Result = datalist.ToList();
            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }
        public ResponseResultDto<SubSystemModel> DeleteSubSystem(List<string> ids)
        {
            ResponseResultDto<SubSystemModel> res = new ResponseResultDto<SubSystemModel>();
            try
            {
                var sysyIds = new List<Guid>();
                foreach (var id in ids)
                {
                    sysyIds.Add(new Guid(id));
                }

                var subsystem = subSysDb.Query().Where(p => !p.DeFlag && sysyIds.Contains(p.ID));
                if (subsystem.Any())
                {
                    subSysDb.Delete(subsystem);
                    subSysDb.SaveChanged();
                }

                res.IsSuccess = true;
            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }
        public ResponseResultDto<SubSystemModel> SaveOrUpdateSubSystem(SubSystemModel subSystemModel)
        {
            ResponseResultDto<SubSystemModel> res = new ResponseResultDto<SubSystemModel>();
            try
            {
                if (subSystemModel == null)
                {
                    res.IsSuccess = false;
                    res.ErrorMessage = "传入数据为空,保存失败";
                    return res;
                }

                if (subSystemModel.Id == Guid.Empty)
                {
                    var con = new SubSystem()
                    {
                        ID = Guid.NewGuid(),
                        Name = subSystemModel.Name,
                        Icon = subSystemModel.Icon,
                        Seq = subSystemModel.Seq,
                        OptUser = "gzy"
                    };
                    subSysDb.Insert(con);
                    subSysDb.SaveChanged();
                }
                else
                {
                    var sub = subSysDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == subSystemModel.Id);
                    if (sub != null)
                    {
                        sub.Name = subSystemModel.Name;
                        sub.Icon = subSystemModel.Icon;
                        sub.Seq = subSystemModel.Seq;
                        sub.Version = sub.Version + 1;
                        sub.OptDate = DateTime.Now;
                        subSysDb.Update(sub);
                        subSysDb.SaveChanged();
                    }
                }

                res.IsSuccess = true;

            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }
        #endregion
        #region FuncUnit
        public ResponseResultDto<FuncUnitModels> QueryFuncUnitModels(string name, Guid subId, Pagination pagination)
        {
            ResponseResultDto<FuncUnitModels> res = new ResponseResultDto<FuncUnitModels>();
            try
            {
                var funts = funDb.Query().Where(p => !p.DeFlag);
                if (!string.IsNullOrEmpty(name))
                {
                    funts = funts.Where(p => p.Name.Contains(name));
                }

                if (subId != Guid.Empty)
                {
                    funts = funts.Where(p => p.SubSystemID == subId);
                }

                var datas = funts.Select(p => new FuncUnitModels()
                {
                    Id = p.ID,
                    Name = p.Name,
                    FuncMainView = p.FuncMainView,
                    Seq = p.Seq,
                    SubSystemID = p.SubSystemID,
                    BelongModule = p.BelongModule,
                    SubStstemName = subSysDb.Query().Where(o => !o.DeFlag && o.ID == p.SubSystemID).Select(o => o.Name)
                        .FirstOrDefault()
                });
                if (pagination != null)
                {
                    datas = datas.GetPagination(pagination);
                }
                res.IsSuccess = true;
                res.Result = datas.ToList();
            }
            catch (Exception e)
            {

                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }

            return res;
        }

        public ResponseResultDto<FuncUnitModels> SaveOrUpdateFuncUnitModels(FuncUnitModels funcUnitModel)
        {
            ResponseResultDto<FuncUnitModels> res = new ResponseResultDto<FuncUnitModels>();
            try
            {
                if (funcUnitModel.Id != Guid.Empty)
                {
                    //修改
                    var funmodels = funDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == funcUnitModel.Id);
                    if (funmodels != null)
                    {
                        funmodels.Name = funcUnitModel.Name;
                        funmodels.BelongModule = funcUnitModel.BelongModule;
                        funmodels.FuncMainView = funcUnitModel.FuncMainView;
                        funmodels.Seq = funmodels.Seq;
                        funmodels.OptDate = DateTime.Now;
                        funmodels.Version = funmodels.Version + 1;
                        funDb.Update(funmodels);
                        funDb.SaveChanged();
                        res.IsSuccess = true;
                    }
                }
                else
                {
                    //新增
                    var con = new FuncUnit()
                    {
                        Name = funcUnitModel.Name,
                        FuncMainView = funcUnitModel.FuncMainView,
                        BelongModule = funcUnitModel.BelongModule,
                        Seq = funcUnitModel.Seq,
                        SubSystemID = funcUnitModel.SubSystemID,
                        OptUser = "gzy"
                    };
                    funDb.Insert(con);
                    funDb.SaveChanged();
                    res.IsSuccess = true;
                }
            }
            catch (Exception e)
            {

                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }

            return res;
        }

        public ResponseResultDto<SubSystemModel> DeleteFuncUniSubSystem(List<string> ids)
        {
            ResponseResultDto<SubSystemModel> res = new ResponseResultDto<SubSystemModel>();
            try
            {
                var sysyIds = new List<Guid>();
                foreach (var id in ids)
                {
                    sysyIds.Add(new Guid(id));
                }

                var funtIds = funDb.Query().Where(p => !p.DeFlag && sysyIds.Contains(p.ID));
                if (funtIds.Any())
                {
                    funDb.Delete(funtIds);
                    funDb.SaveChanged();
                    res.IsSuccess = true;
                }


            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }


        #endregion
        #region User
        public ResponseResultDto<UserModels> QueryUserModels(string username, string rolename, Pagination pagination)
        {
            ResponseResultDto<UserModels> res = new ResponseResultDto<UserModels>();
            try
            {
                var users = userDb.Query().Where(p => !p.DeFlag);
                if (!string.IsNullOrEmpty(username))
                {
                    users = users.Where(p => p.UserName.Contains(username));
                }

                if (!string.IsNullOrEmpty(rolename)&&!rolename.Equals("00000000-0000-0000-0000-000000000000"))
                {
                    users = users.Where(p => p.UserRoles == rolename);
                }

                var datas = users.Select(p => new UserModels()
                {
                    Id = p.ID,
                    UserName = p.UserName,
                    LoginName = p.LoginName,
                    Password = p.Password,
                    StartDate = p.StartDate,
                    EndDate = p.EndDate,
                    Email = p.Email,
                    BelongID = p.BelongID,
                    UserRoles = p.UserRoles,
                    DefaultView = p.DefaultView
                });
                if (pagination != null)
                {
                    datas = datas.GetPagination(pagination);
                }


                res.IsSuccess = true;
                res.Result = datas.ToList();

            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }
        public bool SaveOrUpdateUsers(UserModels userModels)
        {
            try
            {                            
                if (userModels.Id == Guid.Empty)
                {
                    //新增
                    var con=new User()
                    {
                        UserName= userModels.UserName,
                        LoginName = userModels.LoginName,
                        Password = GzyCryptography.GetMd5Hash(userModels.Password),
                        StartDate = DateTime.Now,
                        Email = userModels.Email,
                        BelongID = Guid.Empty,
                        UserType= UserType.Administrator,
                        UserRoles= userModels.UserRoles,
                        DefaultView= userModels.DefaultView,
                        OptUser = "admin"
                    };
                    userDb.Insert(con);
                    userDb.SaveChanged();
                }
                else
                {
                    var user = userDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == userModels.Id);
                    if (user != null)
                    {
                        if (userModels.Password.Length < 32)//判断密码是否更改，根据MD5的加密结果是128bit的大整数，用16进制字符来表示的话，一共有32个字符
                        {
                            user.Password = GzyCryptography.GetMd5Hash(userModels.Password);
                        }

                        user.LoginName = userModels.LoginName;
                        user.UserName = userModels.UserName;
                        user.Email = userModels.Email;
                        user.Version = user.Version + 1;
                        user.OptDate = user.OptDate;
                        userDb.Update(user);
                        userDb.SaveChanged();
                    }
                }
                return true;

            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                return false;
            }
          
        }
        public bool DeleteUser(List<string> ids)
        {
            try
            {
                var userIds = new List<Guid>();
                foreach (var id in ids)
                {
                    userIds.Add(new Guid(id));
                }

                var users = userDb.Query().Where(p => !p.DeFlag && userIds.Contains(p.ID));
                if (users.Any())
                {
                    userDb.Delete(users);
                    userDb.SaveChanged();
                    
                }
                return true;
            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                return false;
            }
        }
        #endregion

        #region Role

        public ResponseResultDto<UserRoleModels> QueryUserRoleModels()
        {
            ResponseResultDto<UserRoleModels> res = new ResponseResultDto<UserRoleModels>();
            try
            {

                var userroloe = roleDb.Query().Where(p => !p.DeFlag).Select(p => new UserRoleModels()
                {
                    Id = p.ID,
                    Name = p.Name
                });
                res.IsSuccess = true;
                res.Result = userroloe.ToList();

            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }
            return res;
        }

        

        public bool SaveOrUpdateRole(UserRoleModels userRoleModels)
        {
            try
            {
                if (userRoleModels.Id == Guid.Empty)
                {
                    //新增
                    var role = new Role()
                    {
                        Name = userRoleModels.Name,
                        OptUser = "admin",
                        UserType = UserType.Administrator
                    };
                    roleDb.Insert(role);
                    roleDb.SaveChanged();

                }
                else
                {
                    //修改
                    var role = roleDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == userRoleModels.Id);
                    if (role != null)
                    {
                        role.Name = userRoleModels.Name;
                        role.OptDate=DateTime.Now;
                        role.Version = role.Version + 1;
                        roleDb.Update(role);
                        roleDb.SaveChanged();
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                return false;
            }
            
            
        }

        public List<RoleAuthorizeModels> GetRoleAuthorizeModels(Guid roleId, Pagination pagination)
        {
            try
            {
                var da=new List<RoleAuthorizeModels>();
                var funt = funDb.Query().Where(p => !p.DeFlag);
                var rolefunt = roleAuthorizeDb.Query(p => !p.DeFlag&&p.Role.ID==roleId);
                var checkfun = rolefunt.Select(p => p.FuncUnit.ID);
                var nocheckfun = funt.Where(p =>! checkfun.Contains(p.ID));
                var da1 = nocheckfun.Select(p => new RoleAuthorizeModels()
                {
                    Id = p.ID,
                    RoleId = Guid.Empty,
                    FuncUnitName = p.Name,
                    IsChecked = false
                });
                var da2 = rolefunt.Select(p => new RoleAuthorizeModels()
                {
                    Id = p.FuncUnit.ID,
                    RoleId = p.Role.ID,
                    FuncUnitName = p.FuncUnit.Name,
                    IsChecked = true
                });
                da.AddRange(da1);
                da.AddRange(da2);
                var datas = da.AsQueryable();
                if (pagination != null)
                {

                    datas=datas.GetPagination(pagination);
                }
                return datas.ToList();


            }
            catch (Exception e)
            {
                log.LogError(e.Message);
                return null;
            }
        }

        public bool SaveRoleAuthorize(Guid roleid, List<string> funtId)
        {
            try
            {
                var rolefunits = roleAuthorizeDb.Query().Where(p => !p.DeFlag && p.Role.ID == roleid);
                roleAuthorizeDb.Delete(rolefunits);
                roleAuthorizeDb.SaveChanged();

                foreach (var ss in funtId)
                {
                    var rolafun = roleAuthorizeDb.Query()
                        .FirstOrDefault(p => !p.DeFlag && p.Role.ID == roleid && p.FuncUnit.ID == new Guid(ss));
                    if (rolafun == null)
                    {
                        var role = roleDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == roleid);
                        var con = new RoleAuthorize()
                        {
                            Role = role,
                            FuncUnit = funDb.Query().FirstOrDefault(p => !p.DeFlag && p.ID == new Guid(ss)),
                            OptUser = "gzy"
                        };
                        roleAuthorizeDb.Insert(con);
                        roleAuthorizeDb.SaveChanged();
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                log.LogError(e.Message);
                return false;
            }
           

            
        }








        #endregion



    }



}
