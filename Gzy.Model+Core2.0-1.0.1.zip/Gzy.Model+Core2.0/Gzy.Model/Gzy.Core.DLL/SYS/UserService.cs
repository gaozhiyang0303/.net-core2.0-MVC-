﻿using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.IRepositories;
using Gzy.Core.Service.DTOS;
using Gzy.Core.Service.ISYS;
using Gzy.Core.Service.Models;
using Gzy.EF.Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using Gzy.Core.Model;
using Gzy.CorePublic;
using Gzy.Core.Domain;

namespace Gzy.Core.DLL.SYS
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userDb;
        private readonly ISubSystemRepository subSysDb;
        private readonly IFuncUnitRepository funcDb;
        private readonly ILogger log;
        public UserService(IUserRepository context, ISubSystemRepository subSysContext, IFuncUnitRepository funcontext, ILogger<UserService> log)
        {

            this.userDb = context;
            this.subSysDb = subSysContext;
            this.funcDb = funcontext;
            this.log = log;
        }

        

        /// <summary>
        /// 用户名和密码登陆
        /// </summary>
        /// <param name="loginname"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public ResponseResultDto<UserModels> Login(string loginname, string password)
        {
            ResponseResultDto<UserModels> res = new ResponseResultDto<UserModels>();
            try
            {
                password = GzyCryptography.GetMd5Hash(password);
                if (string.IsNullOrEmpty(loginname) || string.IsNullOrEmpty(password))
                {
                    res.ErrorMessage = "用户名或者密码为空,请检查!";
                }
                else
                {
                    var user = userDb.Query().FirstOrDefault(p => !p.DeFlag && p.LoginName == loginname);
                    if (user == null)
                    {
                        res.ErrorMessage = "用户名不存在,请注册!";
                    }
                    else
                    {
                        if (!user.Password.Equals(password))
                        {
                            res.ErrorMessage = "密码错误,请重新输入!";
                        }
                        else
                        {
                            var da = new List<UserModels>();
                            da.Add(new UserModels()
                            {
                                Id = user.ID,
                                LoginName = user.LoginName,
                                Password = user.Password,
                                UserName = user.UserName

                            });
                            //db.UpdateAsync(user);
                            res.IsSuccess = true;
                            res.Result = da;
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                log.LogError(ex, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";

            }
            return res;
        }
        /// <summary>
        /// 获取基础导航菜单栏信息
        /// </summary>
        /// <returns></returns>
        public ResponseResultDto<SubSystemFuncUnitModels> GetSystemFuncUnitModels()
        {
            ResponseResultDto<SubSystemFuncUnitModels> res = new ResponseResultDto<SubSystemFuncUnitModels>();
            try
            {
                var da=new List<SubSystemFuncUnitModels>();
                var subsystems = subSysDb.Query().Where(p => !p.DeFlag);
                if (subsystems.Any())
                {
                    foreach (var subsystem in subsystems)
                    {
                        var funct = funcDb.Query().Where(p => !p.DeFlag && p.SubSystemID == subsystem.ID).Select(p =>
                            new FuncUnitModelses()
                            {
                                Id = p.ID,
                                FuncUnitName = p.Name,
                                FunMainView=string.Format("{0}|{1}",p.BelongModule,p.FuncMainView)
                            }).ToList();
                        da.Add(new SubSystemFuncUnitModels()
                        {
                            Id = subsystem.ID,
                            SubSystemName = subsystem.Name,
                            FuncUnit = funct
                        });
                        
                    }
                    res.IsSuccess = true;
                    res.Result = da;

                }
           
               
            }
            catch (Exception e)
            {
                log.LogError(e, "服务错误");
                res.IsSuccess = false;
                res.ErrorMessage = "服务错误，请稍后重试";
            }

            return res;
        }
    }
}
