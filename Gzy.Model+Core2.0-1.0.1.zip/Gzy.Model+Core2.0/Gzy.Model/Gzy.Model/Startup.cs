﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Gzy.Core.DLL.SYS;
using Gzy.Core.Domain;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.IRepositories;
using Gzy.Core.Model;
using Gzy.Core.Model.Repositories;
using Gzy.Core.Service.IService;
using Gzy.Core.Service.ISYS;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Gzy.Model
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var ss = @"server=127.0.0.1;DataBase=Gzy.Model;uid=sa;pwd=123456";
            services.AddDbContext<BaseDbContext>(option => option.UseSqlServer(ss, b => b.UseRowNumberForPaging()));//采用数据库分页Skip().Take()需要这么设置
            services.AddLogging();

            services.Add(new ServiceDescriptor(typeof(DbContext), typeof(BaseDbContext), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(IUserRepository), typeof(UserRepository), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(ISubSystemRepository), typeof(SubSystemRepository), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(IFuncUnitRepository), typeof(FuncUnitRepository), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(IRoleRepository), typeof(RoleRepository), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(IRoleAuthorizeRepository), typeof(RoleAuthorizeRepository), ServiceLifetime.Scoped));

            services.Add(new ServiceDescriptor(typeof(IUserService), typeof(UserService), ServiceLifetime.Scoped));
            services.Add(new ServiceDescriptor(typeof(ISysManagerService), typeof(SysManagerService), ServiceLifetime.Scoped));

            //https://www.cnblogs.com/oorz/p/8617530.html cookie授权登录参考
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
                {
                    options.Cookie.HttpOnly = true;
                    options.Cookie.Expiration = TimeSpan.FromMinutes(30);

                    options.LoginPath = "/Account/Login";
                    options.Cookie.Name = CookieAuthenticationDefaults.AuthenticationScheme;
                });
            services.AddMvc();
            services.AddSession();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseAuthentication();
            app.UseSession();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
