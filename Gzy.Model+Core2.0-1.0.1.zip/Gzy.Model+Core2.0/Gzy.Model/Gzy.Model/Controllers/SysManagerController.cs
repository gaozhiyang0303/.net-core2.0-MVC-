﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gzy.Core.DLL.Model;
using Gzy.Core.Service.IService;
using Gzy.Core.Service.Models;
using Gzy.Core.Service.Models.SysManager;
using Gzy.Core.Service.Models.User;
using Gzy.CorePublic;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using FuncUnitModels = Gzy.Core.Service.Models.SysManager.FuncUnitModels;

namespace Gzy.Model.Controllers
{

    public class SysManagerController : Controller
    {
        public ISysManagerService _service;
        public SysManagerController(ISysManagerService service)
        {
            this._service = service;
        }
        #region SubSystem
        public IActionResult SubSystemIndex()
        {
            return View();
        }
        #region 获取数据表
        
        public IActionResult GetDataList(string name, Pagination pagination)
        {
            var data = _service.QuerySubSystem(name, pagination);
            if (!data.IsSuccess)
            {
                return Content("<script>alert('" + data.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }
            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(data.Result)));
        }
        #endregion

        public IActionResult SubSystemForm(string Id)
        {
            var data = _service.QuerySubSystem("", null);
            if (!data.IsSuccess || string.IsNullOrEmpty(Id))
            {
                return View(new SubSystemModel());
            }
            var thedata = data.Result.FirstOrDefault(p => p.Id == new Guid(Id));
            return View(thedata);
        }

        public bool DeleteData(string ids)
        {
            var aa = string.IsNullOrEmpty(ids) ? null : JsonConvert.DeserializeObject<List<string>>(ids);
            if (aa != null)
            {
                _service.DeleteSubSystem(aa);

            }

            return true;

        }

        public bool SaveData(SubSystemModel sunsystem)
        {
            _service.SaveOrUpdateSubSystem(sunsystem);
            return true;
        }
        #endregion

        #region FuncUnit
        
        public IActionResult FuncUnitIndex()
        {
           
            var data = _service.QuerySubSystem("",null);
            if (!data.IsSuccess)
            {
                return Content("<script>alert('" + data.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }
            return View(data.Result);
        }
        //获取数据
        public IActionResult GetFunDataLIst(string condition, string name, Pagination pagination)
        {
            var res=_service.QueryFuncUnitModels(name, new Guid(condition), pagination);
            if (!res.IsSuccess)
            {
                return Content("<script>alert('" + res.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }
            
            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(res.Result)));
        }

        public IActionResult FuncUnitForm(string Id,string subId)
        {
            var data = _service.QueryFuncUnitModels("",Guid.Empty,null);
            if (!data.IsSuccess ||Id.Equals("Add"))
            {
                return View(new FuncUnitModels()
                {
                    SubSystemID = new Guid(subId)
                });
            }
            var thedata = data.Result.FirstOrDefault(p => p.Id == new Guid(Id));           
            return View(thedata);
        }
        public bool SaveFuncUnitData(FuncUnitModels funcUnitModel)
        {
            var res=_service.SaveOrUpdateFuncUnitModels(funcUnitModel);
            if (!res.IsSuccess)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public bool DeleteFuncUnitData(string ids)
        {
            var aa = string.IsNullOrEmpty(ids) ? null : JsonConvert.DeserializeObject<List<string>>(ids);
            if (aa != null)
            {
                var res=_service.DeleteFuncUniSubSystem(aa);
                return res.IsSuccess;

            }

            return false;
        }
        #endregion
        #region User

        public IActionResult UserIndex()
        {
            var res=_service.QueryUserRoleModels();
            if (!res.IsSuccess)
            {
                return Content("<script>alert('" + res.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }
            return View(res.Result);
        }

        public IActionResult GetUserList(string condition, string name, Pagination pagination)
        {
            var res = _service.QueryUserModels(name, condition, pagination);

            if (!res.IsSuccess)
            {
                return Content("<script>alert('" + res.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }

            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(res.Result)));
        }
        public IActionResult UserForm(string Id, string RoleName)
        {
            var res = _service.QueryUserModels("", "",null);
            if (Id.Equals("Add"))
            {
                return View(new UserModels()
                {
                    UserRoles = RoleName
                });
            }

            var data = res.Result.FirstOrDefault(p => p.Id == new Guid(Id));
            
            return View(data);
        }

        public bool SaveUserData(UserModels userModels)
        {

            return _service.SaveOrUpdateUsers(userModels);
        }

        public bool DeleteUserData(string ids)
        {
            var aa = string.IsNullOrEmpty(ids) ? null : JsonConvert.DeserializeObject<List<string>>(ids);
            if (aa != null)
            {
                return _service.DeleteUser(aa);
                

            }

            return false;
        }
        #endregion

        #region RoleAuthorize

        public IActionResult RoleAuthorizeIndex()
        {
            var res = _service.QueryUserRoleModels();
            return View(res.Result);

            
        }

        #endregion

        public IActionResult GetRoleDataList(Pagination pagination)
        {
            var res = _service.QueryUserRoleModels();
            if (!res.IsSuccess)
            {
                return Content("<script>alert('" + res.ErrorMessage + "')</script>", "text/javascript", Encoding.UTF8);
            }

            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(res.Result)));
        }

        public IActionResult RoleForm(string Id)
        {
           
            if (string.IsNullOrEmpty(Id))
            {
                return View(new UserRoleModels());
            }
            else
            {
                var data = _service.QueryUserRoleModels().Result.FirstOrDefault(p=>p.Id==new Guid(Id));
                
                return View(data);
            }
           
        }
        public bool SaveRoleData(UserRoleModels userRoleModels)
        {
            return _service.SaveOrUpdateRole(userRoleModels);
        }


        public IActionResult GetRoleAuthorizeDataList(string roloeId,Pagination pagination)
        {
           
            if (string.IsNullOrEmpty(roloeId))
            {
                return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(new List<UserRoleModels>())));
            }
            var datas=_service.GetRoleAuthorizeModels(new Guid(roloeId), pagination);
            
            
            return Content(JsonConvert.SerializeObject(pagination.BuildTableResult_DataGrid(datas)));
        }

        public bool SaveRoleAuthorizeData(string roleid,string ids)
        {
            var aa = string.IsNullOrEmpty(ids) ? null : JsonConvert.DeserializeObject<List<string>>(ids);
            if (aa != null)
            {


                return _service.SaveRoleAuthorize(new Guid(roleid), aa);
            }
            return true;
        }
    }
}