﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain
{
    public interface IBaseDao
    {
        T Get<T>(Guid Id) where T : BaseEntity;
 
         List<T> GetObjects<T>() where T:BaseEntity;

        bool Save<T>(T o) where T : BaseEntity;

        bool Update<T>(T o) where T : BaseEntity;
        DbContext DbContext { get; }
       


    }
}
