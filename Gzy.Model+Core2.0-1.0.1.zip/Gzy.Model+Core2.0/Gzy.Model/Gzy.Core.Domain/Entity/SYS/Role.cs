﻿using Gzy.Core.Domain.Enum;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    /// <summary>
    /// 角色
    /// </summary>
    public class Role : BaseEntity
    {
        /// <summary>
        /// 角色名称
        /// </summary>
        public virtual string Name { get; set; }

        public virtual string DefaultView { get; set; }
        public virtual UserType UserType { get; set; }
    }
}
