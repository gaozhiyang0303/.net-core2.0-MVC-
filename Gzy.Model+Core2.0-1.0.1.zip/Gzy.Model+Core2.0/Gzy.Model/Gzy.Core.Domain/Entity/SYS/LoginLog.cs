﻿using System;
using Gzy.Core.Domain.Enum;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    public class LoginLog : BaseEntity
    {
        public virtual User User { get; set; }

        public virtual DateTime? LoginTime { get; set; }

        public virtual DateTime? LastOperatorTime { get; set; }

        public virtual DateTime? LogoutTime { get; set; }

        public virtual string LoginTerm { get; set; }

        public virtual SYSTEMTYPE SystemType { get; set; }
    }
}
