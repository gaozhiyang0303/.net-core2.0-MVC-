﻿using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    public class RoleAuthorize : BaseEntity
    {
        public virtual Role Role { get; set; }

        public virtual FuncUnit FuncUnit { get; set; }

        public virtual bool IsDefaultView { get; set; }
    }
}
