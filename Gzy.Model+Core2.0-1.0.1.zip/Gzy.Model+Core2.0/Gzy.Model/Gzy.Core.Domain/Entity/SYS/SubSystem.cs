﻿using System.ComponentModel.DataAnnotations;
using Gzy.EF.Domain;

namespace Gzy.Core.Domain.Entity.SYS
{
    /// <summary>
    /// 子系统
    /// </summary>
    public class SubSystem : BaseEntity
    {
        /// <summary>
        /// 显示顺序
        /// </summary>
        [Display(Name = "显示顺序", Order = 10)]
        public virtual int Seq { get; set; }

        /// <summary>
        /// 系统名称
        /// </summary>
        [Required]
        [Display(Name = "系统名称", Order = 20)]
        public virtual string Name { get; set; }

        [Display(Name = "图标", Order = 30)]
        public virtual string Icon { get; set; }
    }
}
