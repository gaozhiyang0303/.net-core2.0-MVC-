﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Domain.MappingFluently.SYS
{
    public class RoleMapping : BaseEntityMapping<Role>
    {
        public new void Configure(EntityTypeBuilder<Role> builder)
        {
            builder.Property(t => t.Name).HasColumnName("Seq").IsRequired().HasMaxLength(30);
            builder.Property(t => t.DefaultView).HasColumnName("Name").IsRequired().HasMaxLength(30);
            builder.Property(t => t.UserType).HasColumnName("UserType").IsRequired();

        }
    }
}
