﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Domain.MappingFluently.SYS
{
    public class RoleAuthorizeMapping : BaseEntityMapping<RoleAuthorize>
    {
        public new void Configure(EntityTypeBuilder<RoleAuthorize> builder)
        {
            builder.Property(t => t.Role).HasColumnName("Role_ID").IsRequired();
            builder.Property(t => t.FuncUnit).HasColumnName("FuncUnit_ID").IsRequired();
            builder.Property(t => t.IsDefaultView).HasColumnName("IsDefaultView").IsRequired();

        }
    }
}
