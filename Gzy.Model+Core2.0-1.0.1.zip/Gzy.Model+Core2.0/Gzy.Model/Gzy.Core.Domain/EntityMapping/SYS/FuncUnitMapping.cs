﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Domain.MappingFluently.SYS
{
    public class FuncUnitMapping : BaseEntityMapping<FuncUnit>
    {
        public new void Configure(EntityTypeBuilder<FuncUnit> builder)
        {
            builder.Property(t => t.Name).HasColumnName("Name").IsRequired().HasMaxLength(30);
            builder.Property(t => t.FuncMainView).HasColumnName("FuncMainView").IsRequired().HasMaxLength(30);
            builder.Property(t => t.BelongModule).HasColumnName("BelongModule").IsRequired().HasMaxLength(30);
            builder.Property(t => t.Seq).HasColumnName("Seq");
            builder.Property(t => t.SystemType).HasColumnName("SystemType").IsRequired();
            builder.Property(t => t.SubSystemID).HasColumnName("SubSystemID").IsRequired();
        }
    }
}
