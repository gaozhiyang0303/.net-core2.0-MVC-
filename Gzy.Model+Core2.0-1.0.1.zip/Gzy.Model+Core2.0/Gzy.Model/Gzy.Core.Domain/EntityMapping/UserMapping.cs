﻿using Gzy.Core.Domain.Entity;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Gzy.Core.Domain.EntityMapping
{
    public class UserMapping : BaseEntityMapping<User>
    {
        public new void Configure(EntityTypeBuilder<User> builder)
        {
            builder.Property(t => t.UserName).HasColumnName("UserName").IsRequired().HasMaxLength(30);
            builder.Property(t => t.LoginName).HasColumnName("LoginName").IsRequired().HasMaxLength(30);
            builder.Property(t => t.Password).HasColumnName("Password").IsRequired();
            builder.Property(t => t.StartDate).HasColumnName("StartDate");
            builder.Property(t => t.EndDate).HasColumnName("Password");
            builder.Property(t => t.Email).HasColumnName("Email").IsRequired();
            builder.Property(t => t.BelongID).HasColumnName("BelongID");
            builder.Property(t => t.UserType).HasColumnName("UserType");
            builder.Property(t => t.UserRoles).HasColumnName("UserRoles").IsRequired();
            builder.Property(t => t.DefaultView).HasColumnName("DefaultView").IsRequired();
        }
    }
}
