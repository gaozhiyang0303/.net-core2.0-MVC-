﻿using Gzy.Core.Domain.Entity.SYS;
using Gzy.EF.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gzy.Core.Domain.IRepositories
{
    public interface IRoleAuthorizeRepository:IBaseRepository<RoleAuthorize, Guid>
    {
        
    } 
    
}
