﻿

using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.IRepositories;
using Gzy.EF.Repository;
using Microsoft.EntityFrameworkCore;
using System;

namespace Gzy.Core.Model.Repositories
{
    public class RoleAuthorizeRepository: BaseRepository<RoleAuthorize, Guid>,IRoleAuthorizeRepository
    {
        public RoleAuthorizeRepository(DbContext context) : base(context) { }
    }

}
