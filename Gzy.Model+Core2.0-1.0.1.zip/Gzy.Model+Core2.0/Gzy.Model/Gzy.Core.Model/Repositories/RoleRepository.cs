﻿using System;
using System.Collections.Generic;
using System.Text;
using Gzy.Core.Domain.Entity.SYS;
using Gzy.Core.Domain.IRepositories;
using Gzy.EF.Repository;
using Microsoft.EntityFrameworkCore;

namespace Gzy.Core.Model.Repositories
{
    public class RoleRepository: BaseRepository<Role, Guid>, IRoleRepository
    {
        public RoleRepository(DbContext context) : base(context) { }
    }
}
