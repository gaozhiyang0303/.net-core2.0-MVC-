﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Gzy.Core.Model.Migrations
{
    public partial class admigrationdlo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FuncUnit",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    BelongModule = table.Column<string>(nullable: true),
                    DeFlag = table.Column<bool>(nullable: false),
                    FuncMainView = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    Seq = table.Column<int>(nullable: false),
                    SubSystemID = table.Column<Guid>(nullable: false),
                    SystemType = table.Column<int>(nullable: false),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FuncUnit", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "LoginLog",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    DeFlag = table.Column<bool>(nullable: false),
                    LastOperatorTime = table.Column<DateTime>(nullable: true),
                    LoginTerm = table.Column<string>(nullable: true),
                    LoginTime = table.Column<DateTime>(nullable: true),
                    LogoutTime = table.Column<DateTime>(nullable: true),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    SystemType = table.Column<int>(nullable: false),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoginLog", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    DeFlag = table.Column<bool>(nullable: false),
                    DefaultView = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    UserType = table.Column<int>(nullable: false),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SubSystem",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    DeFlag = table.Column<bool>(nullable: false),
                    Icon = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    Seq = table.Column<int>(nullable: false),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubSystem", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    BelongID = table.Column<Guid>(nullable: false),
                    DeFlag = table.Column<bool>(nullable: false),
                    DefaultView = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    EndDate = table.Column<DateTime>(nullable: true),
                    LoginName = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    Password = table.Column<string>(nullable: true),
                    StartDate = table.Column<DateTime>(nullable: true),
                    UserName = table.Column<string>(nullable: true),
                    UserRoles = table.Column<string>(nullable: true),
                    UserType = table.Column<int>(nullable: false),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.ID);
                    table.UniqueConstraint("AK_User_ID_Name", x => new { x.ID, x.Name });
                    table.ForeignKey(
                        name: "FK_User_LoginLog_ID",
                        column: x => x.ID,
                        principalTable: "LoginLog",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RoleAuthorize",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    DeFlag = table.Column<bool>(nullable: false),
                    FuncUnitID = table.Column<Guid>(nullable: true),
                    IsDefaultView = table.Column<bool>(nullable: false),
                    OptDate = table.Column<DateTime>(nullable: false),
                    OptUser = table.Column<string>(maxLength: 30, nullable: false),
                    RoleID = table.Column<Guid>(nullable: true),
                    Version = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoleAuthorize", x => x.ID);
                    table.ForeignKey(
                        name: "FK_RoleAuthorize_FuncUnit_FuncUnitID",
                        column: x => x.FuncUnitID,
                        principalTable: "FuncUnit",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RoleAuthorize_Role_RoleID",
                        column: x => x.RoleID,
                        principalTable: "Role",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RoleAuthorize_FuncUnitID",
                table: "RoleAuthorize",
                column: "FuncUnitID");

            migrationBuilder.CreateIndex(
                name: "IX_RoleAuthorize_RoleID",
                table: "RoleAuthorize",
                column: "RoleID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RoleAuthorize");

            migrationBuilder.DropTable(
                name: "SubSystem");

            migrationBuilder.DropTable(
                name: "User");

            migrationBuilder.DropTable(
                name: "FuncUnit");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "LoginLog");
        }
    }
}
