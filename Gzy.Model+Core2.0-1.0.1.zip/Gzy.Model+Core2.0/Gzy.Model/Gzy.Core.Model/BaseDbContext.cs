﻿using Domain.MappingFluently.SYS;
using Gzy.Core.Domain.EntityMapping;
using Microsoft.EntityFrameworkCore;

namespace Gzy.Core.Model
{
    public class BaseDbContext: DbContext
    {
        public BaseDbContext() : base()
        {
        }
        public BaseDbContext(DbContextOptions<BaseDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new FuncUnitMapping());
            modelBuilder.ApplyConfiguration(new LoginLogMapping());
            modelBuilder.ApplyConfiguration(new RoleAuthorizeMapping());
            modelBuilder.ApplyConfiguration(new RoleMapping());
            modelBuilder.ApplyConfiguration(new SubSystemMapping());
            modelBuilder.ApplyConfiguration(new UserMapping());
            base.OnModelCreating(modelBuilder);
        }
    }
}
